from django.contrib import admin
from .models import Patient,Doctor,Receptionist,Appointment,Consultation,Certificate
admin.site.register([Patient,Doctor,Receptionist,Appointment,Consultation,Certificate])
