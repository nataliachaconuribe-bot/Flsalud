from functools import wraps
from io import BytesIO

from django.contrib import messages
from django.contrib.auth import authenticate, login
from django.contrib.auth.decorators import login_required
from django.core.exceptions import PermissionDenied
from django.http import HttpResponse
from django.shortcuts import get_object_or_404, redirect, render
from django.utils import timezone
from django.views.decorators.http import require_POST
from reportlab.lib.utils import simpleSplit
from reportlab.pdfgen import canvas

from .forms import AppointmentForm, ConsultationForm
from .models import Appointment, Certificate, Consultation, Patient


def get_role(user):
    if user.is_superuser:
        return 'admin'
    for role in ('doctor', 'receptionist', 'patient'):
        if hasattr(user, role):
            return role
    return None


def role_required(*roles):
    def decorator(view):
        @wraps(view)
        @login_required
        def wrapper(request, *args, **kwargs):
            if get_role(request.user) not in roles:
                raise PermissionDenied
            return view(request, *args, **kwargs)
        return wrapper
    return decorator


def _appointments_for(user):
    role = get_role(user)
    qs = Appointment.objects.select_related('patient__user', 'doctor__user')

    if role in ('admin', 'receptionist'):
        return qs
    if role == 'doctor':
        return qs.filter(doctor__user=user)
    if role == 'patient':
        return qs.filter(patient__user=user)
    return qs.none()


def _certificates_for(user):
    role = get_role(user)
    qs = Certificate.objects.select_related('consultation__appointment__patient__user')

    if role == 'admin':
        return qs
    if role == 'doctor':
        return qs.filter(consultation__appointment__doctor__user=user)
    if role == 'patient':
        return qs.filter(consultation__appointment__patient__user=user)
    return qs.none()


def home(request):
    return render(request, 'core/home.html')


def login_view(request):
    if request.method == 'POST':
        user = authenticate(
            request,
            username=request.POST.get('username'),
            password=request.POST.get('password'),
        )
        if user:
            login(request, user)
            return redirect('dashboard')
        messages.error(request, 'Usuario o contraseña incorrectos.')
    return render(request, 'core/login.html')


@login_required
def dashboard(request):
    today = timezone.localdate()
    context = {
        'today': today,
        'appointments': _appointments_for(request.user).filter(date=today),
    }

    if get_role(request.user) in ('admin', 'receptionist'):
        context.update({
            'patients': Patient.objects.count(),
            'consultations': Consultation.objects.count(),
            'certificates': Certificate.objects.count(),
        })

    return render(request, 'core/dashboard.html', context)


@login_required
def appointments(request):
    return render(request, 'core/appointments.html', {
        'appointments': _appointments_for(request.user)
    })


@role_required('admin', 'receptionist')
def create_appointment(request):
    form = AppointmentForm(request.POST or None)
    if form.is_valid():
        form.save()
        messages.success(request, 'Cita registrada correctamente.')
        return redirect('appointments')
    return render(request, 'core/form.html', {'form': form, 'title': 'Nueva cita'})


@role_required('admin', 'doctor', 'receptionist')
def patients(request):
    return render(request, 'core/patients.html', {
        'patients': Patient.objects.select_related('user').all()
    })


@role_required('admin', 'doctor')
def consultations(request):
    role = get_role(request.user)
    form = ConsultationForm(request.POST or None, user=request.user)

    if form.is_valid():
        c = form.save()
        Appointment.objects.filter(pk=c.appointment_id).update(status='ATENDIDA')
        messages.success(request, 'Consulta registrada correctamente.')
        return redirect('consultations')

    qs = Consultation.objects.select_related(
        'appointment__patient__user',
        'appointment__doctor__user',
        'certificate',
    )
    if role == 'doctor':
        qs = qs.filter(appointment__doctor__user=request.user)

    return render(request, 'core/consultations.html', {
        'consultations': qs,
        'form': form,
    })


@login_required
def certificates(request):
    return render(request, 'core/certificates.html', {
        'certificates': _certificates_for(request.user)
    })


@require_POST
@role_required('admin', 'doctor')
def create_certificate(request, pk):
    consultations_qs = Consultation.objects.select_related(
        'appointment__patient__user', 'appointment__doctor__user'
    )
    if get_role(request.user) == 'doctor':
        consultations_qs = consultations_qs.filter(
            appointment__doctor__user=request.user
        )

    consultation = get_object_or_404(consultations_qs, pk=pk)
    appt = consultation.appointment

    cert, created = Certificate.objects.get_or_create(
        consultation=consultation,
        defaults={
            'text': (
                f'Se hace constar que {appt.patient} fue atendido(a) en consulta '
                f'médica general el {appt.date:%d/%m/%Y} por el/la Dr(a). '
                f'{appt.doctor}. Diagnóstico: {consultation.diagnosis}'
            ),
            'recipe': consultation.prescription,
            'medical_history': appt.patient.medical_history,
        },
    )

    if created:
        messages.success(request, f'Constancia {cert.unique_code} generada correctamente.')
    else:
        messages.info(request, 'Esta consulta ya tenía una constancia.')

    return redirect('certificates')


@login_required
def certificate_pdf(request, pk):
    cert = get_object_or_404(_certificates_for(request.user), pk=pk)
    buf = BytesIO()
    p = canvas.Canvas(buf)
    p.setTitle('Constancia FLSalud')

    p.setFont('Helvetica-Bold', 16)
    p.drawString(72, 780, 'FLSalud - Constancia médica')

    p.setFont('Helvetica', 11)
    p.drawString(72, 750, f'Código: {cert.unique_code}')
    p.drawString(72, 732, f'Paciente: {cert.consultation.appointment.patient}')
    p.drawString(72, 714, f'Fecha: {cert.admission_date:%d/%m/%Y}')

    y = 680
    for line in simpleSplit(cert.text, 'Helvetica', 11, 450):
        p.drawString(72, y, line)
        y -= 16

    if cert.recipe:
        y -= 14
        p.setFont('Helvetica-Bold', 11)
        p.drawString(72, y, 'Indicaciones / Receta:')
        p.setFont('Helvetica', 11)
        y -= 16
        for line in simpleSplit(cert.recipe, 'Helvetica', 11, 450):
            p.drawString(72, y, line)
            y -= 16

    p.save()
    buf.seek(0)
    return HttpResponse(buf.read(), content_type='application/pdf')


@login_required
def profile(request):
    return render(request, 'core/profile.html', {'user': request.user})